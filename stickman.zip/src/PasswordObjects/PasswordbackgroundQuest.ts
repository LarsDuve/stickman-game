/// <reference path="../gameObjects.ts" />

class PasswordbackgroundQuest extends GameObjects {

    constructor (xPos: number, yPos: number){
        super("password-quest", "./assets/imgPassword/password-quest.png", xPos, yPos);        
        }

}