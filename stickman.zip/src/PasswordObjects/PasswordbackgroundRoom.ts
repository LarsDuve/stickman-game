/// <reference path="../gameObjects.ts" />

class PasswordbackgroundRoom extends GameObjects {

    constructor (xPos: number, yPos: number){
        super("livingroom-empty", "./assets/imgPassword/livingroom-empty.png", xPos, yPos);        
        }

}