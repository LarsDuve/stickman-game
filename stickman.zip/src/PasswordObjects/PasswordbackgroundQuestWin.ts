/// <reference path="../gameObjects.ts" />

class PasswordbackgroundQuestWin extends GameObjects {

    constructor (xPos: number, yPos: number){
        super("password-quest-win", "./assets/imgPassword/password-quest-win.png", xPos, yPos);        
        }

}