/// <reference path="../gameObjects.ts" />

class PasswordbackgroundLaptop extends GameObjects {

    constructor (xPos: number, yPos: number){
        super("laptopscreen", "./assets/imgPassword/laptopscreen.png", xPos, yPos);        
        }

}