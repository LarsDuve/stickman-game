/// <reference path="../gameObjects.ts" />

class CharacterPassword extends GameObjects {

    constructor (xPos: number, yPos: number){
        super("character", "./assets/imgPassword/character.png", xPos, yPos);        
        }

}