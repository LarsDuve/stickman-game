/// <reference path="../gameObjects.ts" />

class PasswordbackgroundQuestFail extends GameObjects {

    constructor (xPos: number, yPos: number){
        super("password-quest-fail", "./assets/imgPassword/password-quest-fail.png", xPos, yPos);        
        }

}