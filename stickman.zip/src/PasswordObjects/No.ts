/// <reference path="../gameObjects.ts" />

class No extends GameObjects {

    constructor (xPos: number, yPos: number){
        super("no", "./assets/imgPassword/no.png", xPos, yPos);        
        }

}