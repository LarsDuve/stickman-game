/// <reference path="../GameObjects.ts" />

class Website extends GameObjects {

    constructor(name: string,imgSrc: string, xPos: number, yPos: number){
        super(name, imgSrc, xPos, yPos);
    }
}