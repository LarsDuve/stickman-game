/// <reference path="../gameObjects.ts"/>
class BackgroundCatfish extends GameObjects {
  


    constructor (xPos: number, yPos: number){
        super("BackgroundCatfish","./assets/imgCatfish/keuken-niet-trans.png", xPos, yPos);
        }



}