/// <reference path="../gameObjects.ts"/>
class BackgroundLaptopCatfish extends GameObjects {
  


    constructor (xPos: number, yPos: number){
        super("BackgroundLaptopCatfish","./assets/imgCatfish/Laptopscherm.png", xPos, yPos);
        }



}